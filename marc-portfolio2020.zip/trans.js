const swup = new Swup({
  plugins: [new SwupOverlayTheme()]
});


new SwupOverlayTheme({
    color: '#FFFFFF',
    duration: 600,
    direction: 'to-right',
});
